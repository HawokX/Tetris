# Tetris

A Pen created on CodePen.io. Original URL: [https://codepen.io/MrDock-/pen/ExGObvp](https://codepen.io/MrDock-/pen/ExGObvp).

Tetris is one of the best games from the most popular console of the 1990s. Do you feel tired of with complicated and difficult games? Did you miss the favorite classic games? Let's play this game to feel nostalgic!
How to play: Move and rotate the falling blocks. Lines are cleared when they are filled with blocks and have no empty spaces